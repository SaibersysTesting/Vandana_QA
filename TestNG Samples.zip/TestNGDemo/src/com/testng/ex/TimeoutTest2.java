package com.testng.ex;


	import org.testng.annotations.Test;

	public class TimeoutTest2{
		
		@Test (timeOut = 2500)
		
		public void test1()
		{
			
			try
			{
				Thread.sleep(2000);
			}
			
			catch (InterruptedException e)
			{
				
			}
		}


}
