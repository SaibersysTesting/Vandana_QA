package com.testng.ex;

import org.testng.annotations.Test;

public class TestWithDepends {
	
	
	
@Test (dependsOnMethods = {"test5"})
	
	public void test1()
	{
		System.out.println("test1");
		
	}
	
	@Test (invocationCount = 4)
	
	public void test2() throws InterruptedException
	{
		System.out.println("login");
		
	}
	
@Test (priority = 2 )
	
	public void test3()
	{
		System.out.println(" test 3");
		
	}

@Test (priority = 2 )

public void test4()
{
	System.out.println(" test 4");
	
}

@Test (priority = 2 )

public void test5()
{
	System.out.println(" test 5");
	
}

}
