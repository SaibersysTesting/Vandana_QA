package com.testng.ex;

import org.testng.annotations.Test;

public class TimeoutTest {
	
	@Test (timeOut = 1000)
	
	public void test1()
	{
		
		try
		{
			Thread.sleep(2000);
		}
		
		catch (InterruptedException e)
		{
			
		}
	}

}
