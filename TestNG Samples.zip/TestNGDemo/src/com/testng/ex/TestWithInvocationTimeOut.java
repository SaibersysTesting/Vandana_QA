package com.testng.ex;

import org.testng.annotations.Test;

public class TestWithInvocationTimeOut {

	
@Test 
	
	public void test1()
	{
		System.out.println("test1");
		
	}
	
	@Test (invocationCount = 4 , invocationTimeOut = 3000)
	
	public void test2() throws InterruptedException
	{
		
		Thread.sleep(1000);
		System.out.println("login");
		
	}
	
@Test (priority = 2 )
	
	public void test3()
	{
		System.out.println(" test 3");
		
	}

@Test (priority = 2 )

public void test4()
{
	System.out.println(" test 4");
	
}

@Test (priority = 2 )

public void test5()
{
	System.out.println(" test 5");
	
}

}
