package com.testng.ex;

import org.testng.annotations.Test;

public class TestWithPriority {
	
	
	@Test (priority = 0)
	
	public void signUp()
	{
		System.out.println("signUp");
		
	}
	
	@Test (priority = 1)
	
	public void login()
	{
		System.out.println("login");
		
	}
	
@Test (priority = 2 )
	
	public void viewBalance()
	{
		System.out.println("view Balance");
		
	}
}
