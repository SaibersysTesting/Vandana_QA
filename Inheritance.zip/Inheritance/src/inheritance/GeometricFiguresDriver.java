package inheritance;
/*
 * @author Vandana Nidasanametla
 */

public class GeometricFiguresDriver
{
	public static void main(String[] args)
	{
		Point origin = new Point ();
		Point point1 = new Point(3.0, 5.0);
		MySquare square1 = new MySquare(4.0);
		MyRectangle rectangle1 = new MyRectangle(point1, 4.0, 7.0);
		AbstractGeometricFigure abstractGeomSquare = new MySquare(origin, 2);
		
		
		System.out.println(
			square1.getCorner() + " " + square1.area());
		System.out.println(
			rectangle1.getCorner() + " " + rectangle1.area());
		System.out.println(
			abstractGeomSquare.getCorner() + " " + abstractGeomSquare.area());
		
		square1.setWidth(3.0);
		System.out.println(
			abstractGeomSquare.getCorner() + " " + abstractGeomSquare.area());
				
		square1.setLength(8.0);
		System.out.println();
		System.out.println(
			square1.getCorner() + " " + square1.area());	
		
		System.out.println();
		System.out.println(square1);
		System.out.println(rectangle1);
		System.out.println("\nInformation of abstractGeomRect");
		System.out.println(abstractGeomSquare.area());
		
		
		/*
		 * Try removing the comment symbol for the next statement and play with the error.
		 * !ENJOY
		 */
		//System.out.println(abstractGeomSquare.getLength());
		
		MySquare casted=(MySquare)abstractGeomSquare;
		System.out.println(casted.getLength());
		
		
	}
}
