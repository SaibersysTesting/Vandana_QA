/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author Vandana Nidasanametla
 */
public class MySquare extends MyRectangle {
    /**
 *
 * no arg constructors
 */
   public MySquare() {
       super(new Point(),0.0,0.0);
       /**
 *
 * constructors with two parameters
 * @param cornerIn
 * @param lengthIn
 * 
 */
   }
    public MySquare(Point cornerIn, double lengthIn)
    {
        super(cornerIn, lengthIn, lengthIn);
        
    }
    /**
 *
 * constructors with one parameter
 * @param lengthIn
 */
    public MySquare(double lengthIn)
    {
        super(new Point(),lengthIn, lengthIn);
    }
    /**
 *
 * @param widthIn
 */

    @Override
 
    public void setWidth(double widthIn)
    {
        super.setWidth(widthIn);
        super.setLength(widthIn);
    }
    /**
 *
 * @param lengthIn
 */
    
    @Override
    public void setLength(double lengthIn)
    {
        super.setLength(lengthIn);
        super.setWidth(lengthIn);
    }
    
    
    @Override
    public String toString()
    {
        return "Corner: "+new Point().toString()+"\n"+"Length: "+super.getLength();
    }
}
    



