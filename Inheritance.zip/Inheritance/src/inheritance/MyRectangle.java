/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;


/**
 *
 * @author Vandana Nidasanametla
 */
public class MyRectangle extends AbstractGeometricFigure{
    
     private double length;
    private double width;
   /**
 *
 * no arg constructor
 */
    
    public MyRectangle() {
        
        super(new Point());
        length=0.0;
        width=0.0;
    }
    /**
 *
 * constructors with three parameters
 * @param cornerIn
 * @param lengthIn
 * @param widthIn
 */
    public MyRectangle(Point cornerIn,double lengthIn, double widthIn) {
        super(cornerIn);
        length = lengthIn;
        width = widthIn;
    }
    /**
 *
 * return area
 */
    @Override
    public double area()
    {
      return length*width;  
    }
    /**
 *
 * @param lengthIn
 */
    public void setLength(double lengthIn) {
        this.length = lengthIn;
    }
    /**
 *
 * @param widthIn 
 */
    public void setWidth(double widthIn) {
        this.width = widthIn;
    }
/**
 *
 * return length
 */
    public double getLength() {
        return length;
    }
/**
 *
 * return width
 */
    
    public double getWidth() {
        return width;
    }
    
    @Override
    public String toString()
    {
        return "Corner: "+super.getCorner()+"\n"+"Length: "+ length+"\n"+"Width: "+width;
    }           
    
    
}
