/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author Vandana Nidasanametla
 */
public class Point {
  
  private  double x;
    private double y;
    
    /**
 *
 * no arg constructors
 */
    
    public Point()
    {
        this.x=0.0;
        this.y=0.0;
    }
    /**
 *
 * constructor with two arguments
 * @param xIn
 * @param yIn 
 */
    public Point(double xIn, double yIn)
    {
        this.x=xIn;
        this.y=yIn;
    }
  
    @Override
    public String toString()
    {
        return "("+x+","+y+")";
    }
}



    

