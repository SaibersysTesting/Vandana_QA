/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author Vandana Nidasanametla
 
 */
public class AbstractGeometricFigure {
    private Point corner;
   /**
 *
 * no arg constructor
 */
     public AbstractGeometricFigure() 
    {
        this(new Point());
    }
     /**
 * constructor with single parameter
 * @param cornerIn
 */
    public AbstractGeometricFigure(Point cornerIn) {
        this.corner = cornerIn;
    }
    /**
 *
 * return 0.0
 */
    public double area(){
        return 0.0;
    }
    
    /**
 *
 * @param pointIn
 */
    public void setCorner(Point pointIn) {
        this.corner = pointIn;
    }
/**
 *
 * return corner
 */
    public Point getCorner() {
        return corner;
    }
    
    
    
    
}

    

