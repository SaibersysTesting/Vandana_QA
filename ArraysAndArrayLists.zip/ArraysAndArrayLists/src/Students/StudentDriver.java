package Students;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 * @author Nidasanametla
 */
public class StudentDriver {
    /**
     *
     * @param args
     * @throws FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
//		This program runs correctly using either the StudentList
//		class or the studentArray class.  Select the one you want to
//		use by commenting out one of the statements below.
//		StudentList listOfStudents = new StudentList();
        StudentArray listOfStudents = new StudentArray();
        Scanner fileReader = new Scanner(new File("Students.txt"));
        while (fileReader.hasNext()) {
            listOfStudents.addStudent(new Student(fileReader.next(),
                    fileReader.next(), fileReader.nextDouble()));
        }
        System.out.println(
                "Total Student objects created from students.txt = "
                + Student.getTotalStudents());
        System.out.println();
        System.out.println(
                "Contents of student list ("
                + listOfStudents.getNumberOfStudents() + " students)");
        System.out.println(listOfStudents);
        System.out.println("Average gpa: " + listOfStudents.findAverageGPA());
        System.out.println();
        System.out.println("Adding one student to end of list");
        Student stu = new Student("Gwen", "DeMarco", 3.4);
        stu.setGpa(3.6);
        listOfStudents.addStudent(stu);
        System.out.println();
        System.out.println(
                "Attempting to add one student to list at index 3");
        stu = new Student("Bilbo", "Baggins", 2.0);
        if (listOfStudents.addStudent(3, stu)) {
            System.out.println("Successfully added");
        } else {
            System.out.println("Unablee to add student");
        }
        System.out.println();
        System.out.println(
                "Attempting to add one student to list at index 40");
        stu = new Student("Fanny", "Brice", 3.0);
        if (listOfStudents.addStudent(40, stu)) {
            System.out.println("Successfully added");
        } else {
            System.out.println("Unable to add student");
        }
        System.out.println();
        System.out.println("Number of students in list: "
                + listOfStudents.getNumberOfStudents());
        System.out.println("Attempting to remove a student at "
                + "index equal to the number of students in the list "
                + "(currently " + listOfStudents.getNumberOfStudents()
                + ")");
        if (listOfStudents.removeStudent(
                listOfStudents.getNumberOfStudents())) {
            System.out.println("Successfully removed");
        } else {
            System.out.println("Unable to remove");
        }
        System.out.println();
        System.out.println("Attempting to remove a student at index 5");
        if (listOfStudents.removeStudent(5)) {
            System.out.println("Successfully removed");
        } else {
            System.out.println("Unable to remove");
        }
        System.out.println();
        System.out.println("Attempting to remove a student at index 20");
        if (listOfStudents.removeStudent(20)) {
            System.out.println("Successfully removed");
        } else {
            System.out.println("Unable to remove");
        }
        System.out.println();
        System.out.println("Contents of student list ("
                + listOfStudents.getNumberOfStudents() + " students)");
        System.out.println("Contents of list");
        System.out.println(listOfStudents.toString());
        System.out.println("Average gpa: " + listOfStudents.findAverageGPA());
        System.out.println();
        System.out.println(
                "Total Student objects created = "
                + Student.getTotalStudents());
    }
}