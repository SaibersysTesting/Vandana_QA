package Students;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Nidasanametla
 */
public class StudentArray {
    private Student[] stuArray;
    private int numberOfStudents;
    private final int MAX = 100;
   
    public StudentArray() {
        stuArray = new Student[MAX];
        numberOfStudents = 0;
    }
   
    public boolean addStudent(Student studentIn) {
        if (numberOfStudents >= stuArray.length) {
            return false;
        }
        stuArray[numberOfStudents] = studentIn;
        numberOfStudents++;
        return true;
    }
   
    public boolean addStudent(int studentPosition, Student student) {
        if (studentPosition > numberOfStudents) {
            return false;
        }
        for (int i = numberOfStudents-1; i >= studentPosition; i--) {
            stuArray[i + 1] = stuArray[i];
        }
        stuArray[studentPosition] = student;
        numberOfStudents++;
        return true;
    }
   
    public int getNumberOfStudents() {
        return numberOfStudents;
    }
    
    public double findAverageGPA() {
        if(stuArray.length == 0) return 0.0;
        double totalGPA = 0.0;
        for (int i = 0; i < numberOfStudents; i++) {
            totalGPA += stuArray[i].getGpa();
        }
        return totalGPA / numberOfStudents;
    }
    
    public boolean removeStudent(int studentPosition) {
        if (numberOfStudents <= studentPosition) {
            return false;
        }
        for (int i = studentPosition; i < numberOfStudents - 1; i++) {
            stuArray[i] = stuArray[i + 1];
        }
        numberOfStudents--;
        return true;
    }
   
    @Override
    public String toString() {
        String str = "";
        for (int i = 0; i < numberOfStudents; i++) {
            str += stuArray[i];
        }
        return str;
    }
}