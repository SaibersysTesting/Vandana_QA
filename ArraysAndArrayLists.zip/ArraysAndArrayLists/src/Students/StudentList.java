/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Students;
import java.util.ArrayList;
/**
 *
 * @author Nidasanametla
 */
public class StudentList {
    private ArrayList<Student> stuArrayList;
   
    public StudentList() {
        stuArrayList = new ArrayList<>();
    }
   
    public boolean addStudent(Student studentIn) {
        return stuArrayList.add(studentIn);
    }
   
    public boolean addStudent(int studentPosition,
            Student student) {
        if (stuArrayList.size() <= studentPosition) {
            return false;
        }
        stuArrayList.add(studentPosition, student);
        return true;
    }
   
    public int getNumberOfStudents() {
        return stuArrayList.size();
    }
   
    public double findAverageGPA() {
        if(stuArrayList.isEmpty()) return 0.0;
        double totalGPA = 0.0;
        for (Student s : stuArrayList) {
            totalGPA += s.getGpa();
        }
        return totalGPA / stuArrayList.size();
    }
    public boolean removeStudent(int studentPosition) {
        if (stuArrayList.size() <= studentPosition) {
            return false;
        }
        stuArrayList.remove(studentPosition);
        return true;
    }
    @Override
    public String toString() {
        String str = "";
        for (Student s : stuArrayList) {
            str += s.toString();
        }
        return str;
    }
}