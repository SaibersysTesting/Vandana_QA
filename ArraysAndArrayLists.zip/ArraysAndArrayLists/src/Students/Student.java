package Students;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Nidasanametla
 */
public class Student {
    private String firstName;
    private String lastName;
    private double gpa;
    private static int totalStudents = 0;
    public Student(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
    public Student(String firstName, String lastName, double gpa) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gpa = gpa;
        totalStudents++;
    }
    public String getFirstName() {
        return firstName;
    }
    
    public double getGpa() {
        return gpa;
    }
    public String getLastName() {
        return lastName;
    }
    public void setGpa(double gpa) {
        this.gpa = gpa;
    }
    public static int getTotalStudents() {
        return totalStudents;
    }
    @Override
    public String toString() {
        String str = "";
        str += String.format("Name: %-9s %-9s GPA: %3.1f%n", this.firstName, this.lastName, this.gpa);
        return str;
    }
}