package mailingtestngreport;

public class EmailableReportRun {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		EmailableReport etr=new EmailableReport();
		etr.execute("emailable-report.html");
	}

}
