package mailingtestngreport;

import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.PasswordAuthentication;
import javax.mail.MessagingException;

public class EmailableReport {
	
	public static void execute(String reportFileName) throws Exception {

		  String username = "raghavreddylankala@gmail.com";
		  String password = "10D41a1220.";

		  Properties props = new Properties();
		  props.put("mail.smtp.starttls.enable", "true");
		  props.put("mail.smtp.auth", "true");
		  props.put("mail.smtp.host", "smtp.gmail.com");
		  props.put("mail.smtp.port", "587");

		   Session session = Session.getDefaultInstance(props,
		    new javax.mail.Authenticator() {
		     protected PasswordAuthentication getPasswordAuthentication() {
		      return new PasswordAuthentication(username, password);
		     }
		    });
		   try {
		    Message message = new MimeMessage(session);		    
		   message.setFrom(new InternetAddress(username));
		   message.setRecipients(Message.RecipientType.TO,
		     InternetAddress.parse("yaswanthsvit11@gmail.com"));
		   message.setSubject("Reports Availalbe!");
		   message.setText("Dear Mail Crawler,"
		     + "\n\n No spam to my email, please!");

		    MimeBodyPart messageBodyPart = new MimeBodyPart();

		    Multipart multipart = new MimeMultipart();

		    messageBodyPart = new MimeBodyPart();
		   String file = "C:\\Users\\ragar\\workspace\\DataReadingTestNG\\test-output\\";
		   String fileName = reportFileName;
		   DataSource source = new FileDataSource(file + fileName);
		   messageBodyPart.setDataHandler(new DataHandler(source));
		   messageBodyPart.setFileName(fileName);
		   multipart.addBodyPart(messageBodyPart);

		    message.setContent(multipart);
		   System.out.println("Sending");
		   Transport.send(message);
		   System.out.println("Done");
		  } catch (MessagingException e) {
		   throw new RuntimeException(e);
		  }
		 }
}
