package frameworkspackage;

import java.io.IOException;
import java.sql.SQLException;

public class Test {

	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		DatabaseReading db = new DatabaseReading();
		ExcelReading eSheet = new ExcelReading();
		eSheet.excelReading();
		db.dataBaseConnection();
	}
}
