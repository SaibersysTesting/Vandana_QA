package frameworkspackage;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReading {
	public String[][] excelReading() throws IOException {

		File src = new File("C:\\Users\\ragar\\Desktop\\TestData.xlsx");

		FileInputStream fis = new FileInputStream(src);

		XSSFWorkbook wb = new XSSFWorkbook(fis);

		int rowCount = wb.getSheetAt(0).getLastRowNum();
		int colCount = wb.getSheetAt(0).getRow(0).getLastCellNum();

		String[][] excelData = new String[rowCount + 1][colCount];
		// String[][] accountCredentials;

		String data = "";

		for (int i = 0; i <= rowCount; i++) {
			for (int j = 0; j < colCount; j++) {
				data = wb.getSheetAt(0).getRow(i).getCell(j).getStringCellValue();
				excelData[i][j] = data;
			}
		}

		wb.close();
		return excelData;
	}
}
