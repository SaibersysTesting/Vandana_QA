package com.automation.pnc;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PncSearch {
	
	WebDriver driver = new FirefoxDriver();
	
	@BeforeTest
	public void openTestSite(){		
		  driver.manage().window().maximize();
		  driver.get("https://www.pnc.com/en/personal-banking.html");
		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
    @Test
    public void getSearchCount() { 	  
	  driver.findElement(By.xpath(".//*[@id='navSearchField']")).sendKeys("industry");
	  driver.findElement(By.xpath(".//*[@id='searchSubmit']")).click();
	  String numberOfFinanceElements = driver.findElement(By.xpath(".//*[@id='container']/div[2]/div[2]/div/div/div/div[1]/div/div/div/div[1]/p")).getText();
	  String[] elements = numberOfFinanceElements.split(" ");
	  System.out.println(elements[0]);	  
  }
    @AfterTest
    public void quitBrowser(){
    	driver.quit();
    }
}
