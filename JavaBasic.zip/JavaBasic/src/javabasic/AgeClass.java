package javabasic;

public class AgeClass {

	public void age(){
		System.out.println("18");
	}
	
}
