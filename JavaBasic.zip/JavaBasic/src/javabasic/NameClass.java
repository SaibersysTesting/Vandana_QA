package javabasic;

public class NameClass {
	
	public void Name(){
		System.out.println("Raghu");
	}

}
