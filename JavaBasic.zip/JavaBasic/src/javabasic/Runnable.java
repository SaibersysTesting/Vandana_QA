package javabasic;

public class Runnable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AgeClass age = new AgeClass();
		NameClass name = new NameClass();
		
		age.age();
		name.Name();

	}

}
