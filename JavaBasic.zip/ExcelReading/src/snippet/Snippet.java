package snippet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Snippet {
	public String[][] excelReading() throws IOException{
	        File src = new File("C:\\Users\\ragar\\Desktop\\TestData.xlsx");
			
			FileInputStream fis = new FileInputStream(src);
			
			XSSFWorkbook wb = new XSSFWorkbook(fis);		
			
			int rowCount = wb.getSheetAt(0).getLastRowNum();
			int colCount = wb.getSheetAt(0).getRow(0).getLastCellNum();
			//System.out.println(rowCount);
			//System.out.println(colCount);
			
			String[][] excelData = new String[rowCount][colCount];
			//List<String> usernameList = new ArrayList<String>();
			//List<String> passwordList = new ArrayList<String>();
			
			String data = "";
			String username = "";
			String password = "";
			for(int i=0;i<rowCount;i++){
				for(int j=0;j<colCount;j++){
					
					//wb.getSheetAt(0).getRow(i).getCell(j).getStringCellValue();
					data = wb.getSheetAt(0).getRow(i).getCell(j).getStringCellValue();
					excelData[i][j] = data;			
					//System.out.println(data);					
				}
				System.out.println();
			}		
			
			for(int i=0;i<rowCount;i++)
			{
				for(int j = 0; j<colCount;j++)
				{
					System.out.print(excelData[i][j]+" ");
				}
				System.out.println("");
			}
				
			return excelData;		
	
		}
}

