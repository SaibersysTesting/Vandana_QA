package firsttestngpackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class FirstTestNGFile {
  @Test
  public void verifyHomepageTitle() {
	  WebDriver driver = new FirefoxDriver();
	  driver.get("http://newtours.demoaut.com");
	  String expectedTitle = "Welcome: Mercury Tours";
	  String actualTitle = driver.getTitle();
	  System.out.println(actualTitle);
	  Assert.assertEquals(actualTitle, expectedTitle);
	  
	  
	  driver.findElement(By.linkText("REGISTER")).click();
	  System.out.println(driver.getTitle());
	  //driver.quit();
  }
}
