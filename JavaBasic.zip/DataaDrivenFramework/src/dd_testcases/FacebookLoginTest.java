package dd_testcases;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import dd_core.testCore;
import dd_util.testUtil;


public class FacebookLoginTest extends testCore {

	@BeforeTest
	public void isSkip(){
		if(!testUtil.isExecutable("facebooklogintest")){
			throw new SkipException("This Test is skipped because the runmode is set to No");
		}
	}

    @Test(dataProvider="data")	
	public void doLogin(String username, String password) {
    	try{
    	app_Logs.debug("Executing FacebookLoginTest");
		driver.findElement(By.xpath(object.getProperty("username"))).sendKeys(username);
		driver.findElement(By.xpath(object.getProperty("password"))).sendKeys(password);
		driver.findElement(By.xpath(object.getProperty("logIn"))).click();
    	}catch(Throwable t){
    		testUtil.captureScreenshot();
    		Assert.assertTrue(false, t.getMessage());
    	}

	}	
    
    @DataProvider
    public static Object[][] data(){
    	return testUtil.getData("FacebookLoginTest");
    }
    
	

}
