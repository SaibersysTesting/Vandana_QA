package arraysinterviewquestion;

public class runner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DuplicateandUniqueElementFinder duFinder = new DuplicateandUniqueElementFinder();
		int[] array1 = {12,23,34,45,56,67,90};
		int[] array2 = {12,67,45,9,56,89,14,89,78};
		duFinder.findDuplicate(array1, array2);
		duFinder.findUnique(array1, array2);
		duFinder.findUniqueArrays(array1, array2);
	}

}
