package arraysinterviewquestion;

import java.util.ArrayList;
import java.util.List;

public class DuplicateandUniqueElementFinder {

	public void findDuplicate(int[] array1, int[] array2) {
		System.out.println("Duplicate elements are");
		for (int i = 0; i < array1.length; i++) {
			for (int j = 0; j < array2.length; j++) {
				if (array1[i] == array2[j]) {
					System.out.print(array1[i] + " ");
				}
			}
		}
	}

	public void findUniqueArrays(int[] array1, int[] array2) {
		System.out.println();
		System.out.println("Unique elements using Arrays");

		List<Integer> uniqueList = new ArrayList<>();

		for (int i = 0; i < array1.length; i++) {
			int count = 0;
			for (int j = 0; j < array2.length; j++) {
				if (array1[i] == array2[j]) {
					count++;
				}
			}
			if (count == 0) {
				uniqueList.add(array1[i]);
			}
		}

		for (int i = 0; i < array2.length; i++) {
			int count = 0;
			for (int j = 0; j < array1.length; j++) {
				if (array2[i] == array1[j]) {
					count++;
				}
			}
			if (count == 0) {
				uniqueList.add(array2[i]);
			}
		}

		for (int elements : uniqueList) {
			System.out.print(elements + " ");
		}
	}

	public void findUnique(int[] array1, int[] array2) {
		List<Integer> list1 = new ArrayList<>();
		List<Integer> list2 = new ArrayList<>();

		List<Integer> uniqueList = new ArrayList<>();

		System.out.println();
		System.out.println("Unique elements are");

		for (int list1Element : array1) {
			list1.add(list1Element);
		}

		for (int list2Element : array2) {
			list2.add(list2Element);
		}

		for (int element : list1) {
			if (!list2.contains(element)) {
				uniqueList.add(element);
			}
		}

		for (int element : list2) {
			if (!list1.contains(element)) {
				uniqueList.add(element);
			}
		}

		for (int uniqueElements : uniqueList) {
			System.out.print(uniqueElements + " ");
		}
	}
}
