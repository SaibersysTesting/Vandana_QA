package DataDriven;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ReadExcel {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		File src = new File("C:\\Users\\ragar\\Desktop\\TestData.xlsx");
		
		FileInputStream fis = new FileInputStream(src);
		
		XSSFWorkbook wb = new XSSFWorkbook(fis);		
		
		int rowCount = wb.getSheetAt(0).getLastRowNum();
		int colCount = wb.getSheetAt(0).getRow(0).getLastCellNum();
		//System.out.println(rowCount);
		//System.out.println(colCount);
		
		String[][] excelData = new String[rowCount][colCount];
		//List<String> usernameList = new ArrayList<String>();
		//List<String> passwordList = new ArrayList<String>();
		
		String data = "";
		String username = "";
		String password = "";
		for(int i=0;i<rowCount;i++){
			for(int j=0;j<colCount;j++){
				
				//wb.getSheetAt(0).getRow(i).getCell(j).getStringCellValue();
				data = wb.getSheetAt(0).getRow(i).getCell(j).getStringCellValue();
				excelData[i][j] = data;			
				//System.out.println(data);					
			}
			System.out.println();
		}		
		
		for(int i=0;i<rowCount;i++)
		{
			for(int j = 0; j<colCount;j++)
			{
				System.out.print(excelData[i][j]+" ");
			}
			System.out.println("");
		}
			
		
		
		//driver.get("https://www.gmail.com");
		WebDriver driver = new FirefoxDriver();
		
		driver.get("https://www.gmail.com");
		
		for(int i=0;i<rowCount;i++){
			
			
			for(int j=0; j<colCount;j++){
		//enters email id
				
		driver.findElement(By.id("Email")).sendKeys(excelData[i][j]);
		//clicks on next button.
		driver.findElement(By.id("next")).click();				
	
		//To avoid synchronization problem.
		driver.manage().timeouts().implicitlyWait(30000, TimeUnit.SECONDS);
		//Enters password
		driver.findElement(By.id("Passwd")).sendKeys(excelData[i][++j]);
		//clicks on sign in button
		driver.findElement(By.id("signIn")).click();
		//to click on logout icon
		driver.findElement(By.xpath(".//span[@class='gb_Za gbii']")).click();
		//to click on signout button.
		driver.findElement(By.linkText("Sign out")).click();
		driver.manage().timeouts().implicitlyWait(5000,TimeUnit.SECONDS);
		//to clear cache
		driver.manage().deleteAllCookies();
		//driver.close();
			}
	    driver.navigate().to("https://www.gmail.com");
		}
	}

}
