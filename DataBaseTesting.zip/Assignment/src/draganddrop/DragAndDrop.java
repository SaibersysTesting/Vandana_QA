package draganddrop;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class DragAndDrop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://jqueryui.com/droppable/");		
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
		
		driver.switchTo().frame(driver.findElement(By.className("demo-frame")));
		WebElement element = driver.findElement(By.xpath(".//*[@id='draggable']"));
		
		WebElement target = driver.findElement(By.xpath(".//*[@id='droppable']"));
		
		Actions action = new Actions(driver);
	    Action dragDrop = action.dragAndDrop(element, target).build();
	    dragDrop.perform(); 
		
	}

}
