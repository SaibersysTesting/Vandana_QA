package dd_util;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;



import dd_core.testCore;

public class testUtil extends testCore {
	
	public static boolean isExecutable(String tcid) {

		for (int rowNum = 2; rowNum <= excel.getRowCount("test_suite"); rowNum++) {

			if (excel.getCellData("test_suite", "tcid", rowNum).equalsIgnoreCase(tcid)) {
				if (excel.getCellData("test_suite", "runmode", rowNum).equalsIgnoreCase("y")) {
					return true;
				} else {
					return false;
				}
			}
		}

		return false;
	}
	
public static Object[][] getData(String sheetName){
		 
		 
		
		int rows = excel.getRowCount(sheetName);  // Get Row Count
		int cols = excel.getColumnCount(sheetName);  // Get Col Count
		Object data[][] = new Object[rows-1][cols]; //-1
	
		
		for(int rowNum = 2 ; rowNum <= rows ; rowNum++){ //2
			
			for(int colNum=0 ; colNum< cols; colNum++){
				
				data[rowNum-2][colNum]=excel.getCellData(sheetName, colNum, rowNum); //-2
			}
		}
	
	return data;
	
	
}

public static void captureScreenshot(){
	
	Calendar calendar = new GregorianCalendar();
	int month = calendar.get(Calendar.MONTH);
	int date = calendar.get(Calendar.DATE);
	int year = calendar.get(Calendar.YEAR);
	int Hour = calendar.get(Calendar.HOUR);
	int minute = calendar.get(Calendar.MINUTE);
	int second = calendar.get(Calendar.SECOND);
	
	File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	try{
		String mailScreenshotPath = System.getProperty("user.dir")+"\\Screenshots\\"+month+"_"+date+"_"
				+year+"_"+Hour+"_"+minute+"_"+second;
		
		FileUtils.copyFile(scrFile, new File(mailScreenshotPath));
	}catch(IOException e){
		e.printStackTrace();
	}
	
}

}
